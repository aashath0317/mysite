<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_code = $_GET['code'];
	echo 'Valid response';

}