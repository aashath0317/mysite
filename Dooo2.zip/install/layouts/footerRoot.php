<!-- JAVASCRIPT -->
<script src="public/libs/jquery/jquery.min.js"></script>
<script src="public/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="public/libs/metismenu/metisMenu.min.js"></script>
<script src="public/libs/simplebar/simplebar.min.js"></script>
<script src="public/libs/node-waves/waves.min.js"></script>

<script src="public/js/app.js"></script>

</body>

</html>