<?php

$servername = "enter_hostname";
$username = "enter_db_username";
$password = "enter_db_password";
$dbname = "enter_database_name";

?>